import type {Metadata, Viewport} from 'next';
import './globals.css';
import {ThemeProvider} from '@/components/theme-provider';
import {SiteHeader} from '@/components/site-header';
import {SiteFooter} from '@/components/site-footer';
import {getSiteSettings} from '@/lib/public-data';
import {AnalyticsTracker} from '@/components/analytics-tracker';
import {PageTransition, ScrollProgress} from '@/components/motion-system';
import {IntroGate} from '@/components/intro-gate';

export async function generateMetadata(): Promise<Metadata> {
  const settings = await getSiteSettings();
  const siteUrl = String(
    settings.siteUrl || process.env.NEXT_PUBLIC_SITE_URL || process.env.NEXT_PUBLIC_APP_URL || 'https://smautomations.tech'
  );
  const title = String(settings.seoTitle || 'SM Automations — Intelligent Systems');
  const description = String(
    settings.seoDescription ||
      'Custom AI assistants, intelligent workflow automation and agentic systems that help businesses work smarter.'
  );
  const image =
    typeof settings.socialImage === 'string' && settings.socialImage.startsWith('https://')
      ? settings.socialImage
      : undefined;
  let metadataBase: URL;
  try {
    metadataBase = new URL(siteUrl);
  } catch {
    metadataBase = new URL('https://smautomations.tech');
  }
  return {
    metadataBase,
    title: {default: title, template: '%s | SM Automations'},
    description,
    applicationName: String(settings.brandName || 'SM Automations'),
    openGraph: {
      type: 'website',
      siteName: String(settings.brandName || 'SM Automations'),
      title,
      description,
      images: image ? [image] : undefined
    },
    twitter: {
      card: 'summary_large_image',
      title,
      description,
      images: image ? [image] : undefined
    },
    icons: {icon: '/icon.svg'},
    robots: {index: true, follow: true}
  };
}

export const dynamic = 'force-dynamic';
export const viewport: Viewport = {width: 'device-width', initialScale: 1, themeColor: '#09090d'};

export default async function RootLayout({children}: {children: React.ReactNode}) {
  const settings = await getSiteSettings();
  const showEmail = settings.showEmail !== false;
  const showWhatsApp = settings.showWhatsApp !== false;

  return (
    <html
      lang="en"
      data-theme={
        ['light', 'glass', 'tokyo', 'evolute', 'cinematic', 'editorial', 'slate', 'ink', 'forest'].includes(
          String(settings.themeDefault)
        )
          ? String(settings.themeDefault)
          : 'dark'
      }
      data-layout={['rail', 'bento'].includes(String(settings.siteLayout)) ? String(settings.siteLayout) : 'classic'}
      data-show-marquee={settings.showMarquee === false ? 'false' : 'true'}
      data-show-hero-art={settings.showHeroArt === false ? 'false' : 'true'}
      data-show-ambient={settings.showAmbient === false ? 'false' : 'true'}
      data-show-scroll-progress={settings.showScrollProgress === false ? 'false' : 'true'}
      data-show-cta-rings="false"
      style={
        {
          ['--project-card-height' as string]:
            typeof settings.projectCardHeight === 'string' ? settings.projectCardHeight : 'auto',
          ['--project-thumb-height' as string]:
            typeof settings.projectThumbHeight === 'string' ? settings.projectThumbHeight : '190px',
          ['--project-thumb-height-mobile' as string]:
            typeof settings.projectThumbHeightMobile === 'string' ? settings.projectThumbHeightMobile : '170px'
        } as React.CSSProperties
      }
    >
      <body>
        <a href="#main" className="skip-link">
          Skip to content
        </a>
        <ThemeProvider>
          {settings.showScrollProgress !== false && <ScrollProgress />}
          <IntroGate
            key={String(settings.introPreset || 'breath') + '-' + String(settings.introMode || '')}
            mode={
              (settings.introMode as any) ||
              (settings.introEnabled === false ? 'off' : settings.introEveryVisit === true ? 'always' : 'first')
            }
            preset={String(settings.introPreset || 'breath')}
            customEnabled={settings.introCustomEnabled === true}
            customScenesJson={typeof settings.introScenesJson === 'string' ? settings.introScenesJson : undefined}
          />
          <SiteHeader
            brand={settings.brandName || 'SM Automations'}
            navigationJson={settings.navigationJson}
            layout={String(settings.siteLayout || 'classic')}
          />
          <AnalyticsTracker />
          <PageTransition>{children}</PageTransition>
          <SiteFooter
            brandName={settings.brandName}
            email={settings.email}
            footerText={settings.footerText}
            whatsappNumber={settings.whatsappNumber}
            whatsappMessage={settings.whatsappMessage}
            footerLinksJson={settings.footerLinksJson}
            showEmail={showEmail}
            showWhatsApp={showWhatsApp}
          />
        </ThemeProvider>
      </body>
    </html>
  );
}
