import {notFound, redirect} from 'next/navigation';
import type {Metadata} from 'next';
import {SectionRenderer} from '@/components/section-renderer';
import {getPublishedPage} from '@/lib/public-data';

const fixed=['about','services','projects','industries','insights','faq','contact','privacy','admin'];

export async function generateMetadata({params}:{params:Promise<{slug:string[]}>}):Promise<Metadata>{
  const {slug}=await params;
  const path=slug.join('/');
  const p=await getPublishedPage(path);
  if(!p)return {};
  const canonical = (p.slug === '' || p.slug === 'home') ? '/' : `/${p.slug}`;
  return {
    title:p.seo?.title||p.title,
    description:p.seo?.description||p.description,
    robots:p.status==='published'?{index:true,follow:true}:{index:false,follow:false},
    alternates:{canonical}
  };
}

export default async function DynamicPage({params}:{params:Promise<{slug:string[]}>}){
  const {slug}=await params;
  const path=slug.join('/');
  if(path==='home') redirect('/');
  if(fixed.includes(path)||path.startsWith('api/')) notFound();
  const page=await getPublishedPage(path);
  if(!page) return notFound();
  return <main id="main"><SectionRenderer sections={page.sections}/></main>;
}
