import fs from "node:fs";
import path from "node:path";

const root = process.cwd();
const read = (relative) => fs.readFileSync(path.join(root, relative), "utf8");
const write = (relative, value) => fs.writeFileSync(path.join(root, relative), value, "utf8");
const fail = (message) => { throw new Error(`[redesign patch] ${message}`); };
const PALETTE_VALUES = {"cinema-crimson": ["#07070a", "#111116", "#1c1b22", "#f8f4f1", "#aaa4ab", "#e01836", "#ff506a", "dark"], "obsidian-emerald": ["#06110f", "#0b1d19", "#122b24", "#effff7", "#9dbbb0", "#16b98a", "#5ce6ba", "dark"], "midnight-sapphire": ["#070b1a", "#101831", "#17274a", "#f4f7ff", "#a4b2d2", "#4778ff", "#85a8ff", "dark"], "eclipse-violet": ["#100817", "#1b1027", "#2a173b", "#fbf4ff", "#bda9cb", "#a34cff", "#d18cff", "dark"], "graphite-amber": ["#11100e", "#1d1b17", "#2a261f", "#fff8e9", "#c0b49b", "#f5a623", "#ffd27a", "dark"], "deep-ocean": ["#04121b", "#082331", "#103448", "#effaff", "#9bbdca", "#18b7d8", "#69e4ff", "dark"], "noir-monochrome": ["#080808", "#121212", "#202020", "#fafafa", "#b1b1b1", "#f3f3f3", "#ffffff", "dark"], "ivory-forest": ["#f4f1e7", "#fffdf5", "#e4e8d8", "#20291f", "#6e7b66", "#3c704d", "#6a9d70", "light"], "editorial-sand": ["#f3e8d7", "#fff8ed", "#e8d5bd", "#30241d", "#806c5b", "#b8794d", "#e5a06d", "light"], "sage-cream": ["#edf1e7", "#fbfff7", "#dbe4d0", "#1d2b20", "#5d7160", "#3d7650", "#77a77e", "light"], "lavender-paper": ["#f1effa", "#fffefe", "#e2def2", "#29223e", "#716889", "#7052b8", "#a58ce5", "light"], "terracotta-sunset": ["#f6e8df", "#fff8f2", "#ead2c4", "#38231b", "#846557", "#bd5037", "#ed8664", "light"], "rose-quartz": ["#f8edf0", "#fff9fb", "#eed9e0", "#351d29", "#866778", "#b83d70", "#e878a4", "light"], "electric-pop": ["#08091b", "#11122c", "#20224a", "#f9f7ff", "#b7b3d5", "#5a36ff", "#ff587b", "dark"], "arctic-bloom": ["#edf6fa", "#ffffff", "#dcecf2", "#102b38", "#54717d", "#237c9e", "#67c8d8", "light"]};
function replaceOnce(source, needle, replacement, file) {
  const count = source.split(needle).length - 1;
  if (count !== 1) fail(`${file}: expected exactly one occurrence of patch anchor, found ${count}: ${needle.slice(0, 100)}`);
  return source.replace(needle, replacement);
}
function replaceRegexOnce(source, regex, replacement, file) {
  const matches = [...source.matchAll(new RegExp(regex.source, regex.flags.includes("g") ? regex.flags : regex.flags + "g"))];
  if (matches.length !== 1) fail(`${file}: expected one regex match, found ${matches.length}: ${regex}`);
  return source.replace(regex, replacement);
}

const catalogPath = "lib/design-catalog.ts";
if (!fs.existsSync(path.join(root, catalogPath))) fail(`missing ${catalogPath}; extract the overlay before running this script`);
const catalog = read(catalogPath);
const ids = [...catalog.matchAll(/\bid:\s*"([a-z0-9-]+)"/g)].map((m) => m[1]);
if (ids.length !== 15 || new Set(ids).size !== 15) fail(`catalog must contain exactly 15 unique designs (got ${ids.length})`);
const union = `export type LayoutDesign = ${ids.map((id) => `"${id}"`).join(" | ")};`;

// Replace the union, not the larger shared type file, to avoid touching backend contracts.
{
  const file = "types/index.ts";
  let s = read(file);
  s = replaceRegexOnce(s, /^export type LayoutDesign = .*;$/m, union, file);
  s = replaceRegexOnce(s, /^export type SiteVersion = .*;$/m, 'export type SiteVersion = string; // Legacy Firestore field only; no longer a selectable frontend design.', file);
  write(file, s);
}

// Replace the old palette IDs with the new independent 15-theme catalog.
{
  const file = "types/index.ts";
  let s = read(file);
  const themeSource = read("lib/theme-catalog.ts");
  const themeIds = [...themeSource.matchAll(/\bid: "([a-z0-9-]+)"/g)].map((m) => m[1]);
  if (themeIds.length !== 15 || new Set(themeIds).size !== 15) fail(`theme catalog must contain exactly 15 unique themes (got ${themeIds.length})`);
  s = replaceRegexOnce(s, /^export type ColorTheme = .*;$/m, `export type ColorTheme = ${themeIds.map((id) => `"${id}"`).join(" | ")};`, file);
  write(file, s);
}
{
  const file = "lib/site-defaults.ts";
  let s = read(file);
  s = replaceOnce(s, 'import type { SiteSettings } from "@/types";', 'import type { SiteSettings } from "@/types";\nimport { DEFAULT_COLOR_THEME } from "@/lib/theme-catalog";\nimport { DEFAULT_LAYOUT_DESIGN } from "@/lib/design-catalog";', file);
  s = replaceOnce(s, 'colorTheme: "obsidian-crimson"', 'colorTheme: DEFAULT_COLOR_THEME', file);
  s = replaceOnce(s, 'layoutDesign: "series-cinema"', 'layoutDesign: DEFAULT_LAYOUT_DESIGN', file);
  write(file, s);
}
{
  const file = "components/providers/ThemeProvider.tsx";
  let s = read(file);
  s = replaceOnce(s, 'import { useSiteSettings } from "@/hooks/useSiteSettings";', 'import { useSiteSettings } from "@/hooks/useSiteSettings";\nimport { isColorTheme, DEFAULT_COLOR_THEME } from "@/lib/theme-catalog";', file);
  s = replaceOnce(s, 'root.dataset.colorTheme=settings.appearance.colorTheme||"obsidian-crimson";', 'root.dataset.colorTheme=isColorTheme(settings.appearance.colorTheme)?settings.appearance.colorTheme:DEFAULT_COLOR_THEME;', file);
  s = replaceOnce(s, 'root.dataset.layoutDesign=settings.appearance.layoutDesign||"series-cinema";', 'root.dataset.layoutDesign=isLayoutDesign(settings.appearance.layoutDesign)?settings.appearance.layoutDesign:"cinema-index";', file);
  s = replaceOnce(s, 'import { isColorTheme, DEFAULT_COLOR_THEME } from "@/lib/theme-catalog";', 'import { isColorTheme, DEFAULT_COLOR_THEME } from "@/lib/theme-catalog";\nimport { isLayoutDesign } from "@/lib/design-catalog";', file);
  const themeSource = read("lib/theme-catalog.ts");
  const light = [...themeSource.matchAll(/\{ id: "([a-z0-9-]+)", label: "[^"]+", description: "Light/g)].map(m=>m[1]);
  s = replaceRegexOnce(s, /const light=\[[^\]]*\]\.includes\(root\.dataset\.colorTheme\);/, `const light=${JSON.stringify(light)}.includes(root.dataset.colorTheme);`, file);
  write(file, s);
}
{
  const file = "app/dashboard/settings/page.tsx";
  let s = read(file);
  s = replaceOnce(s, 'import { useSiteSettingsContext } from "@/components/providers/SiteSettingsProvider";', 'import { useSiteSettingsContext } from "@/components/providers/SiteSettingsProvider";\nimport { colorThemeCatalog, isColorTheme, DEFAULT_COLOR_THEME } from "@/lib/theme-catalog";\nimport { isLayoutDesign, layoutDesignCatalog } from "@/lib/design-catalog";', file);
  s = replaceOnce(s, 'import type { PricingTier, SiteSettings, SiteVersion } from "@/types";', 'import type { PricingTier, SiteSettings } from "@/types";', file);
  s = replaceRegexOnce(s, /const siteVersions:Array<\{value:SiteVersion;label:string;description:string\}>= \[[\s\S]*?\];\n/, "", file);
  const swatches = Object.fromEntries(Object.entries(PALETTE_VALUES).map(([id, colors]) => [id, { accent: colors[5], background: colors[0] }]));
  s = replaceRegexOnce(s, /const designs=\[[\s\S]*?\] as const;\n/, 'const colorThemeSwatches: Record<string, { accent: string; background: string }> = ' + JSON.stringify(swatches) + ';\nconst designs = layoutDesignCatalog.map(({ id, label, description }) => [id, label, description] as const);\n', file);
  s = replaceRegexOnce(s, /const themes=\[[\s\S]*?\] as const;\n/, 'const themes = colorThemeCatalog.map(({ id, label, description }) => [id, label, description] as const);\n', file);
  s = replaceRegexOnce(s, /\(\{"obsidian-crimson":"#e5132b"[\s\S]*?\} as Record<string,string>\)\[v\]/, 'colorThemeSwatches[v]?.accent ?? "currentColor"', file);
  s = replaceRegexOnce(s, /\(\{"obsidian-crimson":"#07070a"[\s\S]*?\} as Record<string,string>\)\[v\]/, 'colorThemeSwatches[v]?.background ?? "transparent"', file);
  s = replaceOnce(s, 'useEffect(()=>{getSiteSettings().then(setS).catch(()=>{})},[]);', 'useEffect(()=>{getSiteSettings().then((settings)=>setS({...settings,appearance:{...settings.appearance,layoutDesign:isLayoutDesign(settings.appearance.layoutDesign)?settings.appearance.layoutDesign:"cinema-index",colorTheme:isColorTheme(settings.appearance.colorTheme)?settings.appearance.colorTheme:DEFAULT_COLOR_THEME}})).catch(()=>{})},[]);', file);
  s = replaceOnce(s, 'const appearance={...s.appearance,[key]:value};patch({appearance});const root=document.documentElement;root.dataset[key==="layoutDesign"?"layoutDesign":"colorTheme"]=value;', 'const selected=key==="layoutDesign"?(isLayoutDesign(value)?value:"cinema-index"):(isColorTheme(value)?value:DEFAULT_COLOR_THEME);const appearance={...s.appearance,[key]:selected};patch({appearance});const root=document.documentElement;root.dataset[key==="layoutDesign"?"layoutDesign":"colorTheme"]=selected;', file);
  s = replaceOnce(s, 'value={s.appearance.layoutDesign||"series-cinema"}', 'value={isLayoutDesign(s.appearance.layoutDesign)?s.appearance.layoutDesign:"cinema-index"}', file);
  s = replaceOnce(s, 'value={s.appearance.colorTheme||"obsidian-crimson"}', 'value={isColorTheme(s.appearance.colorTheme)?s.appearance.colorTheme:DEFAULT_COLOR_THEME}', file);
  s = replaceOnce(s, 's.appearance.layoutDesign===v?', '(isLayoutDesign(s.appearance.layoutDesign)?s.appearance.layoutDesign:"cinema-index")===v?', file);
  s = replaceOnce(s, 's.appearance.colorTheme===v?', '(isColorTheme(s.appearance.colorTheme)?s.appearance.colorTheme:DEFAULT_COLOR_THEME)===v?', file);
  const oldLayoutSummary = '{s.appearance.layoutDesign||"series-cinema"}';
  const oldLayoutSummaryCount = s.split(oldLayoutSummary).length - 1;
  if (oldLayoutSummaryCount !== 2) fail(`${file}: expected 2 legacy layout summary values, found ${oldLayoutSummaryCount}`);
  s = s.replaceAll(oldLayoutSummary, '{isLayoutDesign(s.appearance.layoutDesign)?s.appearance.layoutDesign:"cinema-index"}');
  s = replaceOnce(s, '{s.appearance.colorTheme||"obsidian-crimson"}', '{isColorTheme(s.appearance.colorTheme)?s.appearance.colorTheme:DEFAULT_COLOR_THEME}', file);
  s = replaceOnce(s, '15 composition systems. Changing this does not change your color palette.', '15 new composition systems. Changing this does not change your color palette.', file);
  write(file, s);
}

// Replace legacy palette CSS with the new palette definitions; preserve the utility bridge.
{
  const file = "app/theme-versions.css";
  let s = read(file);
  const begin = "/* COLOR THEMES — deliberately separate from layout design. */";
  const end = "/* Bridge legacy Tailwind utility colors to the active palette, including the admin. */";
  const i=s.indexOf(begin), j=s.indexOf(end,i+begin.length);
  if(i<0||j<0||s.indexOf(begin,i+1)>=0) fail(`${file}: unable to isolate legacy palette rules safely`);
  const themeSource=read("lib/theme-catalog.ts");
  const defs = [...themeSource.matchAll(/\{ id: "([a-z0-9-]+)", label: "([^"]+)", description: "([^"]+)" \}/g)];
  const themeLines = defs.map(([_,id,label,description])=>{ const c=PALETTE_VALUES[id]; return `:root[data-color-theme="${id}"] { ${c[7]==="light"?"color-scheme:light;":"color-scheme:dark;"}--cine-bg:${c[0]};--cine-bg-2:${c[1]};--cine-bg-3:${c[2]};--cine-fg:${c[3]};--cine-muted:${c[4]};--cine-border:color-mix(in srgb, ${c[3]} 16%, transparent);--cine-accent:${c[5]};--cine-accent-2:${c[6]}; }`; }).join("\n");
  s=s.slice(0,i)+"/* NEW 15 COLOR THEMES — independent of layout composition. */\n"+themeLines+"\n"+s.slice(j);
  write(file,s);
}

// Activate the replacement layout stylesheet after the independent palette stylesheet.
{
  const file = "app/layout.tsx";
  let s = read(file);
  s = replaceOnce(s, 'import "./theme-versions.css";', 'import "./theme-versions.css";\nimport "./layout-designs.css";\nimport "./admin-layout-designs.css";', file);
  write(file, s);
}

// Remove the obsolete 15-layout CSS block, keeping palette rules and shared motion utilities.
{
  const file = "app/theme-versions.css";
  let s = read(file);
  const begin = "/* Layout design tokens: these affect composition, not the palette. */";
  const end = "/* Motion utilities inspired by the reference implementation. */";
  const i = s.indexOf(begin);
  const j = s.indexOf(end, i + begin.length);
  if (i < 0 || j < 0 || s.indexOf(begin, i + 1) >= 0) fail(`${file}: unable to isolate the old layout CSS block safely`);
  s = s.slice(0, i) + "/* Legacy layout selectors removed. Current compositions live in app/layout-designs.css. */\n" + s.slice(j);
  write(file, s);
}


// Give the authenticated dashboard explicit design hooks while preserving its data logic and auth guard.
{
  const file = "components/dashboard/DashboardFrame.tsx";
  let s = read(file);
  s = replaceOnce(s, 'className="min-h-screen bg-[#020617] text-white"', 'className="admin-design-shell min-h-screen bg-[#020617] text-white" data-admin-design-shell', file);
  write(file, s);
}
{
  const file = "components/dashboard/Sidebar.tsx";
  let s = read(file);
  s = replaceOnce(s, 'className={`fixed inset-y-0 left-0 z-[90] w-[260px] border-r border-white/10 bg-slate-950 transition-transform duration-300 lg:translate-x-0 ${isOpen?"translate-x-0":"-translate-x-full"}`}', 'className={`admin-design-sidebar fixed inset-y-0 left-0 z-[90] w-[260px] border-r border-white/10 bg-slate-950 transition-transform duration-300 lg:translate-x-0 ${isOpen?"translate-x-0":"-translate-x-full"}`}', file);
  write(file, s);
}
{
  const file = "components/dashboard/TopBar.tsx";
  let s = read(file);
  s = replaceOnce(s, 'className="sticky top-0 z-50 flex h-16 items-center gap-4 border-b border-white/10 bg-slate-950/80 px-4 backdrop-blur-xl lg:px-6"', 'className="admin-design-topbar sticky top-0 z-50 flex h-16 items-center gap-4 border-b border-white/10 bg-slate-950/80 px-4 backdrop-blur-xl lg:px-6"', file);
  write(file, s);
}

// Apply the supplied monogram to the existing brand slots.
for (const file of ["components/layout/Navbar.tsx", "components/layout/Footer.tsx"]) {
  let s = read(file);
  if (!s.includes('src="/saad-mark.svg"')) fail(`${file}: expected the current logo source was not found`);
  s = s.replace('src="/saad-mark.svg"', 'src="/saad-monogram.png"');
  write(file, s);
}

// Replace the old fixed-order home page and each legacy section JSX with the new authored section files.
const requiredSections = [
  "components/sections/Hero.tsx", "components/sections/Stats.tsx", "components/sections/About.tsx",
  "components/sections/Services.tsx", "components/sections/Process.tsx", "components/sections/Pricing.tsx",
  "components/sections/Portfolio.tsx", "components/sections/Testimonials.tsx", "components/sections/Blog.tsx",
  "components/sections/FAQ.tsx", "components/sections/Contact.tsx", "components/sections/CTABanner.tsx", "components/redesign/DesignFrame.tsx", "components/redesign/MagneticSurface.tsx",
  "components/layouts/PublicComposition.tsx", "app/page.tsx", "app/layout-designs.css", "app/admin-layout-designs.css", "app/services/page.tsx", "app/services/[slug]/page.tsx", "app/contact/page.tsx", "app/portfolio/page.tsx", "app/blog/page.tsx", "app/blog/[slug]/page.tsx"
];
for (const file of requiredSections) if (!fs.existsSync(path.join(root, file))) fail(`missing new authored section file: ${file}`);
const sectionSources = requiredSections.filter(file => file.startsWith("components/sections/")).map(file => read(file));
for (const name of ["redesign-hero", "redesign-stats", "redesign-about", "redesign-services", "redesign-process", "redesign-pricing", "redesign-portfolio", "redesign-testimonials", "redesign-blog", "redesign-faq", "redesign-contact"]) {
  if (!sectionSources.some(source => source.includes(name))) fail(`section JSX is missing its new implementation marker: ${name}`);
}

// Update the design-system section without erasing the repository's existing handoff instructions.
{
  const file = "WEBSITE_HANDOFF.md";
  if (fs.existsSync(path.join(root, file))) {
    let s = read(file);
    const start = s.indexOf("## Design system\n");
    const end = s.indexOf("## Content editing\n", start);
    const replacement = `## Design system
- The public homepage JSX is newly implemented across Hero, Stats, About, Services, Process, Pricing, Portfolio, Testimonials, Blog, FAQ, and Contact.
- The standalone Services, Portfolio, Blog archive/article, and Contact pages have also been rebuilt with the same visual language.
- Layout catalog: lib/design-catalog.ts — 15 distinct compositions. Palette catalog: lib/theme-catalog.ts — 15 independent color palettes.
- Composition styling lives in app/layout-designs.css; palette tokens live in app/theme-versions.css. Any palette can be combined with any composition.
- The authenticated admin dashboard shares the selected composition and palette through the same document-level tokens, with dashboard-specific rules in app/admin-layout-designs.css and explicit shell/sidebar/top-bar hooks. CRM, analytics, settings, blog CMS, and media-management data flows remain unchanged.
- The portfolio displays published entries only; the testimonial section does not fabricate client quotes. Keep all published claims factual.
- Reference rail and modal behavior is adapted from Sushmitadasari/Portfolio_series; see docs/REFERENCE_CODE_REUSE.md for source-file details and attribution notes.

`;
    if (start >= 0 && end > start) s = s.slice(0, start) + replacement + s.slice(end);
    else s += "\n" + replacement;
    write(file, s);
  }
}
if (fs.existsSync(path.join(root, "DESIGN_VERSIONS.md"))) write("DESIGN_VERSIONS.md", `# Current website design system\n\nThe previous five-version selector and previous layout catalog are retired. Dashboard → Site Settings → Appearance selects one of 15 independent layout compositions and one of 15 independent color palettes. See docs/NEW_LAYOUT_DESIGN_SYSTEM.md for the catalog and structure.\n`);
if (fs.existsSync(path.join(root, "README.md"))) {
  let s = read("README.md");
  const section = "## Current public redesign\n\nThe public homepage section JSX is newly implemented in `components/sections/`. Layout composition is managed in `lib/design-catalog.ts`; the 15 independent palettes are managed in `lib/theme-catalog.ts`. The authenticated dashboard now shares those same 15 composition choices and 15 palettes, with dashboard-specific styling in `app/admin-layout-designs.css`. Dashboard data/auth logic is preserved. See `docs/NEW_LAYOUT_DESIGN_SYSTEM.md` and `docs/REFERENCE_CODE_REUSE.md`.\n\n";
  if (!s.includes("## Current public redesign")) s = s.replace("## Major capabilities\n", "## Major capabilities\n\n" + section);
  write("README.md", s);
}
// Verify the admin shares the same live design tokens and has its own composition-aware styling.
if (!read("components/dashboard/DashboardFrame.tsx").includes("admin-design-shell")) fail("dashboard shell is missing the admin design hook");
if (!read("components/dashboard/Sidebar.tsx").includes("admin-design-sidebar")) fail("dashboard sidebar is missing its design hook");
if (!read("components/dashboard/TopBar.tsx").includes("admin-design-topbar")) fail("dashboard top bar is missing its design hook");
if (!read("app/admin-layout-designs.css").includes('html[data-layout-design="launchpad-constellation"]')) fail("admin CSS does not define all 15 composition-specific rules");
console.log("Applied 15 public compositions, 15 independent palettes, newly authored public section JSX, and shared admin dashboard styling.");
