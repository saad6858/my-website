# Complete public website + admin dashboard redesign patch

This is a repository overlay for `saad6858/my-website`, not a standalone website. It is designed to be applied to the existing Next.js/Firebase/Cloudinary/Netlify repository so the admin, authentication, saved content, API contracts, and media upload pipeline remain intact.

## What is actually replaced

The patch redesigns both the public website and the authenticated admin dashboard. The dashboard uses the same selected layout and palette as the public site, with dedicated composition-aware styling for its shell, navigation, headers, cards, forms, tables, and responsive layouts. Dashboard data fetching, authentication, and CRUD behavior are retained.

The patch overwrites the JSX implementation for all 11 homepage sections: Hero, Stats, About, Services, Process, Pricing, Portfolio, Testimonials, Blog, FAQ, and Contact. It also replaces the public homepage assembly with a 15-layout composition system. The old JSX for those sections is not retained as a hidden alternate design. The standalone Services, Portfolio, Blog archive, Blog article, and Contact routes are also re-authored to use the same visual system; the dynamic service-detail route is rebuilt around the existing service data contract.

The 15 layouts are structurally distinct, with dedicated CSS composition rules, and the 15 palettes are independent. Pointer-responsive magnetic/parallax movement is limited to mouse pointers and disabled when reduced motion is requested. This provides 225 possible layout/palette combinations. The design board is included under `docs/reference/design-board.png`; the supplied monogram is installed at `public/saad-monogram.png`.

## Existing platform features preserved

- Firebase authentication and protected dashboard/admin (the dashboard visuals are redesigned, not the authorization logic)
- Existing Firestore data contracts and API routes
- Existing service and portfolio management
- Existing blog authoring and publishing, including inline media
- Existing Cloudinary upload/storage implementation
- Existing contact submission API and its server-side validation
- Existing SEO, routing, and Netlify runtime
- Existing inline blog video limit of 95,000,000 bytes

## Reference implementation reuse

The portfolio rail and project-modal interaction code from `Sushmitadasari/Portfolio_series` is adapted into this repository's `ProjectRailControls.tsx` and `ProjectModal.tsx`. See `docs/REFERENCE_CODE_REUSE.md` for the exact source files, behavior carried over, and adaptation boundary. The requester reports that the creator gave permission via Instagram; keep that permission record with the project. The reference repository has no repository `LICENSE` file visible in the inspected tree, so attribution and the permission record should remain available.

## Deployment path

1. Create or use a temporary branch named `redesign-patch` from the current `main`.
2. Upload `website-redesign-patch.zip` to the repository root and `APPLY_NEW_LAYOUT_DESIGNS.yml` as `.github/workflows/apply-new-layout-designs.yml` on that branch. Commit both files together so the ZIP and workflow arrive in the same push.
3. Pushing that commit to `redesign-patch` automatically starts the workflow; no workflow file needs to be added to `main` first.
4. The workflow applies the ZIP to a fresh checkout of `main`, verifies the new catalogs, all newly authored sections, the CTA, and protected data/media paths, then runs typecheck, lint, and the production build. Only if every check passes does it push the complete redesign to `main`. That single `main` push is the intended Netlify deployment trigger.

The production build has not been run in this packaging environment because direct GitHub cloning is unavailable here. Treat the result as unverified until this workflow succeeds on the real repository. If the repository's branch protection rules prohibit the Actions token from pushing to `main`, the workflow will stop at the push step rather than bypassing protection.
