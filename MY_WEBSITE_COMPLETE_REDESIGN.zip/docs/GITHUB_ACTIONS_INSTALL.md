# Install and run the redesign workflow

The workflow is deliberately kept on a temporary branch. Uploading the package to `main` could trigger an incomplete Netlify deployment; the workflow makes one push to `main` only after every check succeeds.

## 1. Prepare the upload branch

1. Open `saad6858/my-website` in GitHub and create a branch named exactly `redesign-patch` from the current `main`.
2. On that branch, upload the ZIP as `website-redesign-patch.zip` at the repository root.
3. Upload the separate workflow file as `.github/workflows/apply-new-layout-designs.yml` (create the `.github/workflows` folders if needed).
4. Commit both files together in one commit to `redesign-patch`, not to `main`.

## 2. Let the workflow run

Pushing the upload commit to `redesign-patch` automatically triggers **Apply and verify complete public + admin redesign**. You do not need to use `workflow_dispatch` or add the workflow file to the production branch first.

The workflow validates the ZIP manifest, extracts the overlay into a fresh checkout of `main`, replaces the JSX for all 11 homepage sections and the CTA banner, applies the 15-layout/15-palette catalog edits, wires the authenticated dashboard shell/sidebar/top bar to dashboard-specific composition styling, verifies all 15 admin composition selectors, then runs dependency installation, TypeScript, ESLint, and a Next.js production build. Before pushing the upload commit, add the existing Firebase values as GitHub Actions repository secrets: `NEXT_PUBLIC_FIREBASE_API_KEY`, `NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN`, `NEXT_PUBLIC_FIREBASE_PROJECT_ID`, `NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET`, `NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID`, `NEXT_PUBLIC_FIREBASE_APP_ID`, `FIREBASE_CLIENT_EMAIL`, and `FIREBASE_PRIVATE_KEY`. These are build-only secrets; the workflow does not write them to source files.

Only if every check passes does the workflow push the complete redesign to `main`. That single successful push is the intended Netlify deployment trigger. The workflow does not bypass branch protections; if GitHub denies the Actions token permission to push to `main`, the workflow stops at the push step and the production branch remains unchanged.

## 3. Failure or success

If validation or a build check fails, the workflow stops before pushing to `main`; inspect its first red step and logs. Do not upload an unpacked copy of the ZIP directly over `main` or run the workflow from `main`.

After success, verify the workflow's last commit on `main`, then check the single Netlify deployment and test the public homepage, `/services`, one `/services/[slug]` page, blog, and the admin overview, CRM, analytics, blog editor, media manager, and `/dashboard/settings` → Appearance in at least one dark and one light palette. The ZIP contains no Firebase or Cloudinary secrets.
